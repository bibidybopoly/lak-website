Lak Keyboard Layout — Linux

This archive contains:
  lak          - XKB symbols file (the actual layout definition)
  install.sh   - installer (registers Lak system-wide)
  uninstall.sh - uninstaller
  README.txt   - this file


REQUIREMENTS
------------
- A Linux system using X11 or Wayland (any modern distro).
- The xkeyboard-config package, which provides /usr/share/X11/xkb/
  (this is installed by default on Ubuntu, Fedora, Debian, Arch,
  Pop!_OS, Mint, openSUSE, and basically every desktop Linux).
- python3 (used by install.sh to safely edit XML rule files).


INSTALL
-------
1. Open a terminal in the folder you extracted this archive into.

2. Make the installer executable and run it:

       chmod +x install.sh
       ./install.sh

   The script will ask for your sudo password — it needs root to
   write into /usr/share/X11/xkb/.  It does three things:
     - Copies 'lak' into /usr/share/X11/xkb/symbols/
     - Adds a <layout> entry to /usr/share/X11/xkb/rules/evdev.xml
     - Adds a line to /usr/share/X11/xkb/rules/evdev.lst
   Backups of any modified file are saved as *.lak-backup next to
   the original.

3. Open your desktop's keyboard settings and add Lak as an input
   source:
     GNOME : Settings -> Keyboard -> Input Sources -> +
              -> "Other" group -> "English (Lak)"
     KDE   : System Settings -> Keyboard -> Layouts -> Add Layout
              -> "English (Lak)"
     XFCE  : Settings -> Keyboard -> Layout tab -> Add
     Cinnamon: System Settings -> Keyboard -> Layouts -> +

4. Switch to it with Super+Space, or click your panel's layout
   indicator.  Test by typing a sentence.

If Lak doesn't appear in your desktop's picker, log out and log
back in so the desktop environment re-reads the XKB database.


UNINSTALL
---------
From the same folder where you ran install.sh:

       ./uninstall.sh

It will remove the symbols file and the entries from evdev.xml /
evdev.lst.  If backups exist, they're restored.  After uninstalling,
remove Lak from your desktop's input sources to clean up.


TROUBLESHOOTING
---------------
"Lak doesn't show up in GNOME/KDE settings"
  -> Log out and log back in.  These desktops cache the XKB rules
     database on login.

"setxkbmap: Cannot open display" when testing in a terminal
  -> You're on Wayland.  This is expected — use your desktop
     settings GUI to switch layouts on Wayland.

"My password manager / browser shortcut stopped working"
  -> Some apps bind shortcuts to physical key positions rather
     than the labelled characters.  Switch back to your previous
     layout (Super+Space) when using those apps, or rebind the
     shortcut.

For more help: https://lakkeyboard.com
