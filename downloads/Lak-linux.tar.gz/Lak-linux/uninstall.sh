#!/usr/bin/env bash
# Lak keyboard layout — Linux uninstaller.
#
# Reverses what install.sh did: removes the symbols file and the
# entries in evdev.xml / evdev.lst.  Restores from the .lak-backup
# files if they exist.

set -e

if [ "$(id -u)" -ne 0 ]; then
    echo "This uninstaller needs root privileges. Re-running under sudo..."
    exec sudo -E bash "$0" "$@"
fi

XKB_DIR="/usr/share/X11/xkb"
SYMBOLS_DIR="$XKB_DIR/symbols"
EVDEV_XML="$XKB_DIR/rules/evdev.xml"
EVDEV_LST="$XKB_DIR/rules/evdev.lst"

# 1. Symbols file
if [ -f "$SYMBOLS_DIR/lak.lak-backup" ]; then
    mv "$SYMBOLS_DIR/lak.lak-backup" "$SYMBOLS_DIR/lak"
    echo "Restored previous symbols/lak from backup."
elif [ -f "$SYMBOLS_DIR/lak" ]; then
    rm -f "$SYMBOLS_DIR/lak"
    echo "Removed $SYMBOLS_DIR/lak"
fi

# 2. evdev.xml — remove the <layout> entry whose <name> is 'lak'.
if [ -f "$EVDEV_XML" ]; then
    python3 - "$EVDEV_XML" <<'PY'
import sys, xml.etree.ElementTree as ET
path = sys.argv[1]
tree = ET.parse(path)
root = tree.getroot()
lst = root.find("layoutList")
if lst is None:
    sys.exit(0)
removed = 0
for layout in list(lst.findall("layout")):
    n = layout.find("configItem/name")
    if n is not None and n.text == "lak":
        lst.remove(layout)
        removed += 1
if removed:
    ET.indent(tree, space="  ")
    tree.write(path, encoding="utf-8", xml_declaration=True)
    print(f"  Removed {removed} 'lak' layout entry from evdev.xml.")
else:
    print("  (No 'lak' entry found in evdev.xml — nothing to remove.)")
PY
fi

# 3. evdev.lst — remove the 'lak' line from the layout block.
if [ -f "$EVDEV_LST" ]; then
    python3 - "$EVDEV_LST" <<'PY'
import sys
p = sys.argv[1]
lines = open(p).readlines()
out = []
for ln in lines:
    stripped = ln.lstrip()
    if stripped.startswith("lak") and " " in stripped:
        # Only drop our exact line; preserve unrelated lines starting with "lak"
        first = stripped.split()[0]
        if first == "lak":
            continue
    out.append(ln)
if out != lines:
    open(p, "w").writelines(out)
    print("  Removed 'lak' line from evdev.lst.")
else:
    print("  (No 'lak' line in evdev.lst — nothing to remove.)")
PY
fi

echo ""
echo "Done. Lak has been uninstalled."
echo "Remove it from your desktop's keyboard input sources to clean up."
