Lak Keyboard Layout — macOS

This zip contains a single file: Lak.keylayout

INSTALL
-------
1. Open Finder. From the menu bar, choose Go → Go to Folder…
   (or press Shift + Cmd + G).

2. Type the following path and press Return:

       ~/Library/Keyboard Layouts

   (If that folder doesn't exist yet, create it.)

3. Drag Lak.keylayout into that folder.

4. Log out and log back in.  macOS only scans for new keyboard
   layouts at login — without this step, Lak won't appear.

ENABLE
------
1. Open System Settings → Keyboard.
2. Next to "Input Sources", click Edit… (or "Input Sources" → "+"
   on older macOS versions).
3. Click the "+" button, scroll to the "Others" group at the bottom
   of the language list, and pick Lak.  Click Add.
4. Switch between Lak and your previous layout with Ctrl + Space,
   or click the input-source icon in the menu bar.

UNINSTALL
---------
1. System Settings → Keyboard → Input Sources → Edit → select Lak →
   click the "−" button to remove it from your active sources.
2. Open ~/Library/Keyboard Layouts and move Lak.keylayout to the Trash.
3. Log out and back in to clear the layout from the system.

NOTES
-----
- This file is installed per-user (in your home Library), so no
  admin password is required and other accounts on the Mac are
  unaffected.
- The layout is unsigned.  It's plain XML — you can open it in
  any text editor to inspect every key mapping.
- For installation issues or to report bugs, see https://lakkeyboard.com
