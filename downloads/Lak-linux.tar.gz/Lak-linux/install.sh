#!/usr/bin/env bash
# Lak keyboard layout — Linux installer.
#
# Installs the Lak XKB symbols file system-wide and registers it with
# the X11 keyboard-config rules database, so Lak appears in the
# GNOME / KDE / etc. keyboard settings GUI.

set -e

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

if [ "$(uname -s)" != "Linux" ]; then
    echo "Error: this installer is for Linux only." >&2
    echo "On macOS, install the .keylayout from the Mac download." >&2
    exit 1
fi

if ! command -v python3 >/dev/null 2>&1; then
    echo "Error: python3 is required (used to safely edit evdev.xml)." >&2
    echo "Install it with your package manager and try again." >&2
    exit 1
fi

# Re-exec under sudo if we're not root.  System-wide install needs to
# write to /usr/share/X11/xkb/.
if [ "$(id -u)" -ne 0 ]; then
    echo "This installer needs root privileges to write to /usr/share/X11/xkb/."
    echo "Re-running under sudo..."
    exec sudo -E bash "$0" "$@"
fi

XKB_DIR="/usr/share/X11/xkb"
SYMBOLS_DIR="$XKB_DIR/symbols"
EVDEV_XML="$XKB_DIR/rules/evdev.xml"
EVDEV_LST="$XKB_DIR/rules/evdev.lst"

if [ ! -d "$XKB_DIR" ]; then
    echo "Error: $XKB_DIR not found." >&2
    echo "Your distribution may not use the standard X11 layout database." >&2
    echo "Install the xkeyboard-config package and try again." >&2
    exit 1
fi

if [ ! -f "$SCRIPT_DIR/lak" ]; then
    echo "Error: symbols file 'lak' not found next to install.sh." >&2
    exit 1
fi

echo "Installing Lak symbols file -> $SYMBOLS_DIR/lak"
if [ -f "$SYMBOLS_DIR/lak" ] && [ ! -f "$SYMBOLS_DIR/lak.lak-backup" ]; then
    cp -a "$SYMBOLS_DIR/lak" "$SYMBOLS_DIR/lak.lak-backup"
    echo "  (backed up existing file -> $SYMBOLS_DIR/lak.lak-backup)"
fi
install -m 644 "$SCRIPT_DIR/lak" "$SYMBOLS_DIR/lak"

# --- Register in evdev.xml -------------------------------------------------
echo "Registering Lak in $EVDEV_XML"
if [ -f "$EVDEV_XML" ] && [ ! -f "$EVDEV_XML.lak-backup" ]; then
    cp -a "$EVDEV_XML" "$EVDEV_XML.lak-backup"
    echo "  (backed up original -> $EVDEV_XML.lak-backup)"
fi

python3 - "$EVDEV_XML" <<'PY'
import sys, xml.etree.ElementTree as ET

path = sys.argv[1]
tree = ET.parse(path)
root = tree.getroot()

layout_list = root.find("layoutList")
if layout_list is None:
    sys.exit("evdev.xml has no <layoutList>; aborting.")

# Idempotency: skip if 'lak' is already registered.
for layout in layout_list.findall("layout"):
    name_el = layout.find("configItem/name")
    if name_el is not None and name_el.text == "lak":
        print("  (Lak already registered; leaving evdev.xml unchanged.)")
        sys.exit(0)

# Build new layout entry mirroring upstream layouts (e.g. workman, dvorak).
ns = ""  # evdev.xml does not use namespaces
layout = ET.SubElement(layout_list, "layout")
cfg = ET.SubElement(layout, "configItem")
ET.SubElement(cfg, "name").text = "lak"
ET.SubElement(cfg, "shortDescription").text = "lak"
ET.SubElement(cfg, "description").text = "English (Lak)"
langs = ET.SubElement(cfg, "languageList")
ET.SubElement(langs, "iso639Id").text = "eng"
ET.SubElement(layout, "variantList")

# Pretty-print: ET doesn't preserve indentation perfectly, but write_text-style
# output is fine — desktop environments parse this with a real XML parser.
ET.indent(tree, space="  ")
tree.write(path, encoding="utf-8", xml_declaration=True)
print("  Added <layout name='lak'> entry.")
PY

# --- Register in evdev.lst (legacy text rules) -----------------------------
if [ -f "$EVDEV_LST" ]; then
    echo "Registering Lak in $EVDEV_LST"
    if [ ! -f "$EVDEV_LST.lak-backup" ]; then
        cp -a "$EVDEV_LST" "$EVDEV_LST.lak-backup"
    fi
    if grep -qE '^[[:space:]]*lak[[:space:]]' "$EVDEV_LST"; then
        echo "  (Lak already registered; leaving evdev.lst unchanged.)"
    else
        # Insert "lak  English (Lak)" at the end of the "! layout" block.
        python3 - "$EVDEV_LST" <<'PY'
import re, sys
p = sys.argv[1]
text = open(p).read()
# Find the "! layout" header and the next "!" header after it.
m = re.search(r"(?m)^!\s*layout\s*$", text)
if not m:
    sys.exit("Couldn't find '! layout' section in evdev.lst")
start = m.end()
nxt = re.search(r"(?m)^!\s*\w", text[start:])
end = start + nxt.start() if nxt else len(text)
# Walk back over trailing blank lines so 'lak' lands inside the block,
# not after the visual separator between sections.
block = text[start:end]
trimmed = block.rstrip(" \t\n")
trailing_ws = block[len(trimmed):]
insertion = "  lak             English (Lak)\n"
text = text[:start] + trimmed + "\n" + insertion + trailing_ws + text[end:]
open(p, "w").write(text)
print("  Added 'lak' entry to '! layout' section.")
PY
    fi
fi

echo ""
echo "Done. Lak is installed."
echo ""
echo "Next steps:"
echo "  1. Open your desktop's keyboard settings:"
echo "       GNOME : Settings -> Keyboard -> Input Sources -> +"
echo "       KDE   : System Settings -> Keyboard -> Layouts -> Add Layout"
echo "       XFCE  : Settings -> Keyboard -> Layout -> Add"
echo "  2. Pick 'English (Lak)' from the list."
echo "  3. Switch to it with Super+Space (most desktops) or the"
echo "     layout indicator in your panel."
echo ""
echo "If Lak doesn't appear in the picker, log out and back in so your"
echo "desktop environment re-reads the layout database."
echo ""
echo "To uninstall later, run ./uninstall.sh from this same folder."
